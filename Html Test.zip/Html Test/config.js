export const PRODUCTION = process.env.NODE_ENV == 'production'; // eslint-disable-line

export const hmrEnabled = true;

export const shouldCompressImages = PRODUCTION;
